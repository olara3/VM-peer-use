package com.doti2c.vmperuser.app.dao;

import org.springframework.data.repository.CrudRepository;

import com.doti2c.vmperuser.app.model.Software;

public interface SoftwareDAO extends CrudRepository<Software, Integer> {

}
