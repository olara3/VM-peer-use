package com.doti2c.vmperuser.app.dao;

import org.springframework.data.repository.CrudRepository;

import com.doti2c.vmperuser.app.model.Solicitacao;

public interface SolicitacaoDAO extends CrudRepository<Solicitacao, Integer> {

}
