package com.doti2c.vmperuser.app;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class VmperuseApplication {

	public static void main(String[] args) {
		SpringApplication.run(VmperuseApplication.class, args);
	}

}
